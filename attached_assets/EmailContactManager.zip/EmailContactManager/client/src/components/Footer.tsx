import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-darkText text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h2 className="text-xl font-bold mb-4">Murang'a Marketplace</h2>
            <p className="text-gray-300 mb-4">Connecting local businesses with customers in Murang'a County and beyond.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white">
                <i className="fab fa-facebook-square text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <i className="fab fa-twitter-square text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <i className="fab fa-instagram text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white">Home</Link>
              </li>
              <li>
                <Link href="/businesses" className="text-gray-300 hover:text-white">Businesses</Link>
              </li>
              <li>
                <Link href="/request-service" className="text-gray-300 hover:text-white">Request Service</Link>
              </li>
              <li>
                <Link href="/register-business" className="text-gray-300 hover:text-white">Register Business</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Retail Shops</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Repair Services</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Agriculture</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Professional Services</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Transportation</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <i className="fas fa-envelope mt-1 mr-3 text-gray-400"></i>
                <span className="text-gray-300">murangamarketplace@gmail.com</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-phone mt-1 mr-3 text-gray-400"></i>
                <span className="text-gray-300">0714 092 658</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-gray-400"></i>
                <span className="text-gray-300">Murang'a Town, Kenya</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-700 text-center">
          <p className="text-gray-300">&copy; {new Date().getFullYear()} Murang'a Marketplace. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
