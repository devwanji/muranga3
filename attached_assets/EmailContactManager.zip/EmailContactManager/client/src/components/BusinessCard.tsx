import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StoredBusiness } from "@/lib/store";
import { getCategoryName } from "@/lib/utils";

interface BusinessCardProps {
  business: StoredBusiness;
}

export function BusinessCard({ business }: BusinessCardProps) {
  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="w-full h-48 bg-gray-200">
        {business.category === "repair" && (
          <img 
            src="https://pixabay.com/get/gccdfe5360f75cfa14f5bcd3458a0b3489493c9a3f505436678efac05938f1a17ef60d1233339d4be3842ff6de980ed66c7673bf124874dc29ac029cf6ab28518_1280.jpg" 
            alt={`${business.name}`} 
            className="w-full h-48 object-cover"
          />
        )}
        {business.category === "retail" && (
          <img 
            src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
            alt={`${business.name}`} 
            className="w-full h-48 object-cover"
          />
        )}
        {business.category === "agriculture" && (
          <img 
            src="https://images.unsplash.com/photo-1589923188900-85dae523342b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
            alt={`${business.name}`} 
            className="w-full h-48 object-cover"
          />
        )}
        {!["repair", "retail", "agriculture"].includes(business.category) && (
          <img 
            src="https://images.unsplash.com/photo-1537365587684-f490dff69c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
            alt={`${business.name}`} 
            className="w-full h-48 object-cover"
          />
        )}
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="font-bold text-lg text-darkText">{business.name}</h3>
            <Badge variant="outline" className="bg-green-100 text-primary text-xs px-2 py-1 rounded-full">
              {getCategoryName(business.category)}
            </Badge>
          </div>
          {business.rating && (
            <div className="flex items-center">
              <span className="text-yellow-500 mr-1">{business.rating}</span>
              <i className="fas fa-star text-yellow-500"></i>
            </div>
          )}
        </div>
        <p className="text-gray-600 text-sm mb-4">{business.description}</p>
        <div className="flex items-center text-sm text-gray-500">
          <i className="fas fa-map-marker-alt mr-2 text-primary"></i>
          <span>{business.location}</span>
        </div>
        <div className="flex items-center text-sm text-gray-500 mt-2">
          <i className="fas fa-phone mr-2 text-primary"></i>
          <span>{business.phone}</span>
        </div>
        <div className="mt-4 flex justify-between">
          <Button variant="link" className="text-primary hover:text-secondary font-medium text-sm p-0">
            View Details
          </Button>
          <Link href="/request-service">
            <Button variant="default" className="bg-primary hover:bg-secondary text-white text-sm font-medium px-4 py-2 rounded-md">
              Request Service
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
