import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ChevronDown, Menu } from "lucide-react";
import { useEffect, useState } from "react";
import { getCurrentUser } from "@/lib/store";
import { useAuth } from "@/hooks/useAuth";

export function Navbar() {
  const [location, navigate] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();

  // Check if the link is active
  const isActive = (path: string) => {
    return location === path;
  };

  // Handle login
  const handleLogin = () => {
    navigate("/auth");
  };

  // Handle logout
  const handleLogout = () => {
    logout();
  };

  // Get user role information
  const userRole = user?.role || "customer";
  const userName = user?.firstName && user.firstName !== "null" 
    ? user.firstName 
    : (user?.email ? user.email.split('@')[0] : "User");

  useEffect(() => {
    const closeMenu = () => setIsMenuOpen(false);
    // Close mobile menu on navigation
    closeMenu();
  }, [location]);

  return (
    <nav className="bg-primary shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <span className="text-white text-xl font-bold">Murang'a Marketplace</span>
            </Link>
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/" className={`${isActive("/") ? "bg-secondary" : ""} text-white hover:bg-secondary px-3 py-2 rounded-md text-sm font-medium`}>
              Home
            </Link>
            <Link href="/businesses" className={`${isActive("/businesses") ? "bg-secondary" : ""} text-white hover:bg-secondary px-3 py-2 rounded-md text-sm font-medium`}>
              Businesses
            </Link>
            <Link href="/request-service" className={`${isActive("/request-service") ? "bg-secondary" : ""} text-white hover:bg-secondary px-3 py-2 rounded-md text-sm font-medium`}>
              Request Service
            </Link>
            <Link href="/register-business" className={`${isActive("/register-business") ? "bg-secondary" : ""} text-white hover:bg-secondary px-3 py-2 rounded-md text-sm font-medium`}>
              Register Business
            </Link>
            
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="secondary" className="flex items-center">
                    <span>{userName}</span>
                    <ChevronDown className="ml-1 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {userRole === "admin" && (
                    <DropdownMenuItem onClick={() => navigate("/admin-dashboard")}>
                      Admin Dashboard
                    </DropdownMenuItem>
                  )}
                  {userRole === "business" && (
                    <DropdownMenuItem onClick={() => navigate("/business-dashboard")}>
                      Business Dashboard
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="secondary" className="flex items-center" onClick={handleLogin}>
                <span>Login</span>
              </Button>
            )}
          </div>
          
          {/* Mobile menu */}
          <div className="flex md:hidden items-center">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-primary text-white">
                <div className="flex flex-col space-y-4 mt-8">
                  <Link href="/" className={`${isActive("/") ? "bg-secondary" : ""} hover:bg-secondary px-3 py-2 rounded-md text-base font-medium`}>
                    Home
                  </Link>
                  <Link href="/businesses" className={`${isActive("/businesses") ? "bg-secondary" : ""} hover:bg-secondary px-3 py-2 rounded-md text-base font-medium`}>
                    Businesses
                  </Link>
                  <Link href="/request-service" className={`${isActive("/request-service") ? "bg-secondary" : ""} hover:bg-secondary px-3 py-2 rounded-md text-base font-medium`}>
                    Request Service
                  </Link>
                  <Link href="/register-business" className={`${isActive("/register-business") ? "bg-secondary" : ""} hover:bg-secondary px-3 py-2 rounded-md text-base font-medium`}>
                    Register Business
                  </Link>
                  
                  <div className="py-3 px-3 border-t border-secondary">
                    <p className="text-white font-medium mb-2">
                      {isAuthenticated ? `Logged in as: ${userName}` : "Login to continue"}
                    </p>
                    {isAuthenticated ? (
                      <>
                        {userRole === "admin" && (
                          <button 
                            onClick={() => navigate("/admin-dashboard")}
                            className="block text-white hover:bg-secondary px-3 py-2 rounded-md text-sm text-left w-full"
                          >
                            Admin Dashboard
                          </button>
                        )}
                        {userRole === "business" && (
                          <button 
                            onClick={() => navigate("/business-dashboard")}
                            className="block text-white hover:bg-secondary px-3 py-2 rounded-md text-sm text-left w-full"
                          >
                            Business Dashboard
                          </button>
                        )}
                        <button 
                          onClick={handleLogout}
                          className="block text-white hover:bg-secondary px-3 py-2 rounded-md text-sm text-left w-full"
                        >
                          Logout
                        </button>
                      </>
                    ) : (
                      <button 
                        onClick={handleLogin}
                        className="block text-white hover:bg-secondary px-3 py-2 rounded-md text-sm text-left w-full"
                      >
                        Login
                      </button>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
