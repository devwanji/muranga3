import { Card } from "@/components/ui/card";
import { getCategoryIcon } from "@/lib/utils";

interface CategoryCardProps {
  id: string;
  name: string;
  onClick?: () => void;
}

export function CategoryCard({ id, name, onClick }: CategoryCardProps) {
  const icon = getCategoryIcon(id);
  
  return (
    <Card 
      className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center transition-all hover:shadow-lg hover:-translate-y-1 cursor-pointer"
      onClick={onClick}
    >
      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
        <i className={`fas fa-${icon} text-primary text-2xl`}></i>
      </div>
      <h3 className="font-medium text-darkText">{name}</h3>
    </Card>
  );
}
