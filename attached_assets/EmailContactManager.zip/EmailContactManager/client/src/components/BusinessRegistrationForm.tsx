import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { categories } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { registerBusiness } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  businessName: z.string().min(3, "Business name must be at least 3 characters"),
  businessCategory: z.string().min(1, "Please select a category"),
  contactPerson: z.string().min(3, "Contact person name must be at least 3 characters"),
  businessPhone: z.string().min(10, "Phone number must be at least 10 digits"),
  businessEmail: z.string().email("Invalid email address"),
  businessLocation: z.string().min(3, "Location must be at least 3 characters"),
  businessDescription: z.string().min(10, "Description must be at least 10 characters"),
  subscriptionPlan: z.enum(["monthly", "yearly"]),
  paymentMethod: z.enum(["mpesa", "card"]),
  businessTerms: z.literal(true, {
    errorMap: () => ({ message: "You must accept the terms and conditions" }),
  }),
});

type FormValues = z.infer<typeof formSchema>;

export function BusinessRegistrationForm() {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      businessCategory: "",
      contactPerson: "",
      businessPhone: "",
      businessEmail: "",
      businessLocation: "",
      businessDescription: "",
      subscriptionPlan: "monthly",
      paymentMethod: "mpesa",
      businessTerms: false,
    },
  });

  function onSubmit(data: FormValues) {
    // Convert form data to business registration format
    const business = {
      name: data.businessName,
      category: data.businessCategory,
      contactPerson: data.contactPerson,
      phone: data.businessPhone,
      email: data.businessEmail,
      location: data.businessLocation,
      description: data.businessDescription,
      subscriptionPlan: data.subscriptionPlan,
    };

    // Register the business
    registerBusiness(business);

    // Show success toast
    toast({
      title: "Business registered successfully!",
      description: "You will receive a confirmation email shortly.",
      variant: "default",
    });

    // Reset the form
    form.reset();
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <h3 className="text-xl font-semibold text-darkText mb-6">Business Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="businessName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Business Name *</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="businessCategory"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Business Category *</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="selectCategory">Select a category</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="contactPerson"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contact Person *</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="businessPhone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Business Phone *</FormLabel>
                <FormControl>
                  <Input {...field} type="tel" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="businessEmail"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Business Email *</FormLabel>
              <FormControl>
                <Input {...field} type="email" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="businessLocation"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Business Location *</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="businessDescription"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Business Description *</FormLabel>
              <FormControl>
                <Textarea {...field} rows={4} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="subscriptionPlan"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Subscription Plan *</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="space-y-4"
                >
                  <div className="flex items-center">
                    <RadioGroupItem 
                      value="monthly" 
                      id="monthly" 
                      className="text-primary"
                    />
                    <FormLabel htmlFor="monthly" className="ml-3 block text-sm font-medium text-gray-700">
                      Monthly - Ksh 200/month
                    </FormLabel>
                  </div>
                  <div className="flex items-center">
                    <RadioGroupItem 
                      value="yearly" 
                      id="yearly" 
                      className="text-primary"
                    />
                    <FormLabel htmlFor="yearly" className="ml-3 block text-sm font-medium text-gray-700">
                      Yearly - Ksh 3,000/year (Save 25%)
                    </FormLabel>
                  </div>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="paymentMethod"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Payment Method *</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-wrap gap-4"
                >
                  <div className="flex items-center p-3 border border-gray-300 rounded-md">
                    <RadioGroupItem 
                      value="mpesa" 
                      id="mpesa" 
                      className="text-primary"
                    />
                    <FormLabel htmlFor="mpesa" className="ml-3 block text-sm font-medium text-gray-700">
                      M-Pesa
                    </FormLabel>
                  </div>
                  <div className="flex items-center p-3 border border-gray-300 rounded-md">
                    <RadioGroupItem 
                      value="card" 
                      id="card" 
                      className="text-primary"
                    />
                    <FormLabel htmlFor="card" className="ml-3 block text-sm font-medium text-gray-700">
                      Card Payment
                    </FormLabel>
                  </div>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="businessTerms"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
              <FormControl>
                <Checkbox 
                  checked={field.value} 
                  onCheckedChange={field.onChange} 
                  className="data-[state=checked]:bg-primary" 
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>
                  I agree to the <a href="#" className="text-primary hover:text-secondary">Terms and Conditions</a>
                </FormLabel>
                <FormMessage />
              </div>
            </FormItem>
          )}
        />
        
        <div className="text-center">
          <Button type="submit" className="bg-primary hover:bg-secondary text-white px-6 py-3">
            Register Business
            <i className="fas fa-check-circle ml-2"></i>
          </Button>
        </div>
      </form>
    </Form>
  );
}
