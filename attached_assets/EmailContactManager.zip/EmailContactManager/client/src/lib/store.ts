import { Business, ServiceRequest } from "@shared/schema";
import { calculateSubscriptionExpiry, generateId } from "./utils";

// Define localStorage keys
const BUSINESSES_KEY = "muranga_marketplace_businesses";
const SERVICE_REQUESTS_KEY = "muranga_marketplace_service_requests";
const CURRENT_USER_KEY = "muranga_marketplace_current_user";

// Define user roles
export type UserRole = "admin" | "business" | "customer";

// Define current user type
export interface CurrentUser {
  id: string;
  name: string;
  role: UserRole;
  businessId?: string;
}

// Business type for local storage
export interface StoredBusiness {
  id: string;
  name: string;
  category: string;
  contactPerson: string;
  phone: string;
  email: string;
  location: string;
  description: string;
  subscriptionPlan: "monthly" | "yearly";
  registrationDate: string;
  expiryDate: string;
  status: "active" | "pending" | "expired";
  ownerId: string;
  // Optional fields for UI
  rating?: number;
}

// Service request type for local storage
export interface StoredServiceRequest {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  location: string;
  category: string;
  description: string;
  preferredDate: string;
  status: "new" | "seen" | "in progress" | "completed" | "cancelled";
  timestamp: string;
  businessId: string;
  seen: boolean;
}

// Initialize store with mock data
export function initializeStore() {
  // Only initialize if stores don't exist
  if (!localStorage.getItem(BUSINESSES_KEY)) {
    const initialBusinesses: StoredBusiness[] = [
      {
        id: "b1",
        name: "Kamau Electronics",
        category: "repair",
        contactPerson: "John Kamau",
        phone: "0712345678",
        email: "kamau@example.com",
        location: "Mukuyu Market, Murang'a",
        description: "Specialized in phone, computer and electronics repair services with quality spare parts.",
        subscriptionPlan: "monthly",
        registrationDate: new Date("2023-06-15").toISOString(),
        expiryDate: new Date("2023-07-15").toISOString(),
        status: "active",
        ownerId: "u2",
        rating: 4.8
      },
      {
        id: "b2",
        name: "Wanjiku Fashion House",
        category: "retail",
        contactPerson: "Jane Wanjiku",
        phone: "0723456789",
        email: "wanjiku@example.com",
        location: "Kenol Town, Murang'a",
        description: "Custom tailoring and clothing repairs with a wide selection of fabrics and designs.",
        subscriptionPlan: "yearly",
        registrationDate: new Date("2023-01-10").toISOString(),
        expiryDate: new Date("2024-01-10").toISOString(),
        status: "active",
        ownerId: "u3",
        rating: 4.9
      },
      {
        id: "b3",
        name: "Murang'a Agro Supplies",
        category: "agriculture",
        contactPerson: "James Mwangi",
        phone: "0734567890",
        email: "agro@example.com",
        location: "Muranga Town, Main Street",
        description: "Quality agricultural inputs, tools, and expert advice for local farmers and gardeners.",
        subscriptionPlan: "monthly",
        registrationDate: new Date("2023-05-20").toISOString(),
        expiryDate: new Date("2023-06-20").toISOString(),
        status: "pending",
        ownerId: "u4",
        rating: 4.7
      }
    ];
    localStorage.setItem(BUSINESSES_KEY, JSON.stringify(initialBusinesses));
  }

  if (!localStorage.getItem(SERVICE_REQUESTS_KEY)) {
    const initialRequests: StoredServiceRequest[] = [
      {
        id: "r1",
        customerName: "John Kamau",
        phone: "0712345678",
        email: "johncustomer@example.com",
        location: "Mukuyu, Murang'a",
        category: "repair",
        description: "Phone screen replacement",
        preferredDate: "2023-07-15",
        status: "new",
        timestamp: new Date("2023-07-10").toISOString(),
        businessId: "b1",
        seen: false
      },
      {
        id: "r2",
        customerName: "Mary Wanjiku",
        phone: "0723456789",
        email: "mary@example.com",
        location: "Kenol, Murang'a",
        category: "repair",
        description: "Laptop keyboard repair",
        preferredDate: "2023-07-12",
        status: "new",
        timestamp: new Date("2023-07-09").toISOString(),
        businessId: "b1",
        seen: false
      },
      {
        id: "r3",
        customerName: "James Mwangi",
        phone: "0734567890",
        email: "james@example.com",
        location: "Maragua, Murang'a",
        category: "repair",
        description: "TV repair service",
        preferredDate: "2023-07-08",
        status: "in progress",
        timestamp: new Date("2023-07-05").toISOString(),
        businessId: "b1",
        seen: true
      },
      {
        id: "r4",
        customerName: "Sarah Njeri",
        phone: "0745678901",
        email: "sarah@example.com",
        location: "Kangari, Murang'a",
        category: "repair",
        description: "Computer virus removal",
        preferredDate: "2023-07-03",
        status: "completed",
        timestamp: new Date("2023-07-01").toISOString(),
        businessId: "b1",
        seen: true
      },
      {
        id: "r5",
        customerName: "Sarah Njeri",
        phone: "0745678901",
        email: "sarah@example.com",
        location: "Kangari, Murang'a",
        category: "retail",
        description: "Custom dress alteration",
        preferredDate: "2023-07-05",
        status: "completed",
        timestamp: new Date("2023-07-05").toISOString(),
        businessId: "b2",
        seen: true
      }
    ];
    localStorage.setItem(SERVICE_REQUESTS_KEY, JSON.stringify(initialRequests));
  }
}

// Get all businesses
export function getBusinesses(): StoredBusiness[] {
  const businesses = localStorage.getItem(BUSINESSES_KEY);
  return businesses ? JSON.parse(businesses) : [];
}

// Get business by ID
export function getBusinessById(id: string): StoredBusiness | undefined {
  const businesses = getBusinesses();
  return businesses.find(business => business.id === id);
}

// Get businesses by category
export function getBusinessesByCategory(category: string): StoredBusiness[] {
  const businesses = getBusinesses();
  return businesses.filter(business => business.category === category);
}

// Register a new business
export function registerBusiness(business: Omit<StoredBusiness, "id" | "registrationDate" | "expiryDate" | "status" | "ownerId">): StoredBusiness {
  const businesses = getBusinesses();
  const now = new Date();
  
  const newBusiness: StoredBusiness = {
    ...business,
    id: generateId(),
    registrationDate: now.toISOString(),
    expiryDate: calculateSubscriptionExpiry(business.subscriptionPlan, now).toISOString(),
    status: "active",
    ownerId: getCurrentUser()?.id || generateId(),
  };
  
  businesses.push(newBusiness);
  localStorage.setItem(BUSINESSES_KEY, JSON.stringify(businesses));
  
  return newBusiness;
}

// Get all service requests
export function getServiceRequests(): StoredServiceRequest[] {
  const requests = localStorage.getItem(SERVICE_REQUESTS_KEY);
  return requests ? JSON.parse(requests) : [];
}

// Get service requests by business ID
export function getServiceRequestsByBusiness(businessId: string): StoredServiceRequest[] {
  const requests = getServiceRequests();
  return requests.filter(request => request.businessId === businessId);
}

// Submit a new service request
export function submitServiceRequest(request: Omit<StoredServiceRequest, "id" | "timestamp" | "businessId" | "seen" | "status">): StoredServiceRequest {
  const requests = getServiceRequests();
  const businesses = getBusinesses();
  
  // Find a business matching the category
  const matchingBusiness = businesses.find(b => b.category === request.category && b.status === "active");
  
  const newRequest: StoredServiceRequest = {
    ...request,
    id: generateId(),
    timestamp: new Date().toISOString(),
    businessId: matchingBusiness?.id || "",
    seen: false,
    status: "new"
  };
  
  requests.push(newRequest);
  localStorage.setItem(SERVICE_REQUESTS_KEY, JSON.stringify(requests));
  
  return newRequest;
}

// Update service request status
export function updateServiceRequestStatus(id: string, status: StoredServiceRequest["status"], seen = true): StoredServiceRequest | null {
  const requests = getServiceRequests();
  const index = requests.findIndex(request => request.id === id);
  
  if (index === -1) return null;
  
  requests[index] = {
    ...requests[index],
    status,
    seen
  };
  
  localStorage.setItem(SERVICE_REQUESTS_KEY, JSON.stringify(requests));
  return requests[index];
}

// Get current logged in user
export function getCurrentUser(): CurrentUser | null {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
}

// Set current user
export function setCurrentUser(user: CurrentUser | null): void {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
}

// Get admin statistics
export function getAdminStats() {
  const businesses = getBusinesses();
  const requests = getServiceRequests();
  
  // Calculate revenue
  const revenue = businesses.reduce((total, business) => {
    if (business.subscriptionPlan === "monthly") {
      return total + 200;
    } else {
      return total + 3000;
    }
  }, 0);
  
  // Count expired subscriptions
  const expiredCount = businesses.filter(b => b.status === "expired").length;
  
  return {
    businessCount: businesses.length,
    requestCount: requests.length,
    revenue,
    expiredCount
  };
}

// Get recent businesses (last 3)
export function getRecentBusinesses() {
  const businesses = getBusinesses();
  return businesses
    .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime())
    .slice(0, 3);
}

// Get recent service requests (last 3)
export function getRecentRequests() {
  const requests = getServiceRequests();
  return requests
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 3);
}

// Get business owner statistics
export function getBusinessStats(businessId: string) {
  const requests = getServiceRequestsByBusiness(businessId);
  
  const newRequests = requests.filter(r => r.status === "new");
  const totalRequests = requests.length;
  
  // Get business subscription details
  const business = getBusinessById(businessId);
  
  return {
    newRequestCount: newRequests.length,
    totalRequestCount: totalRequests,
    subscriptionType: business?.subscriptionPlan || "monthly",
    expiryDate: business?.expiryDate || ""
  };
}
