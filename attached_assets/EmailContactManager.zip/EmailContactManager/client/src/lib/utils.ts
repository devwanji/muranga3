import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string) {
  if (!date) return "N/A";
  return new Date(date).toLocaleDateString("en-KE", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatCurrency(amount: number) {
  return new Intl.NumberFormat("en-KE", {
    style: "currency",
    currency: "KES",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function calculateSubscriptionExpiry(type: "monthly" | "yearly", startDate = new Date()) {
  const date = new Date(startDate);
  if (type === "monthly") {
    date.setMonth(date.getMonth() + 1);
  } else {
    date.setFullYear(date.getFullYear() + 1);
  }
  return date;
}

export function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

export function getCategoryIcon(categoryId: string) {
  const icons: Record<string, string> = {
    restaurants: "utensils",
    retail: "shopping-bag",
    repair: "tools",
    agriculture: "tractor",
    professional: "briefcase",
    transport: "truck",
    food: "utensils",
    other: "store"
  };
  return icons[categoryId] || "store";
}

export function getCategoryName(categoryId: string) {
  const names: Record<string, string> = {
    restaurants: "Restaurants",
    retail: "Retail Shops",
    repair: "Repair Services",
    agriculture: "Agriculture",
    professional: "Professional Services",
    transport: "Transport",
    food: "Food & Restaurants",
    other: "Other"
  };
  return names[categoryId] || "Other";
}

export function getStatusColor(status: string) {
  const colors: Record<string, string> = {
    active: "text-green-800 bg-green-100",
    pending: "text-yellow-800 bg-yellow-100",
    expired: "text-red-800 bg-red-100",
    new: "text-red-800 bg-red-100",
    seen: "text-yellow-800 bg-yellow-100",
    "in progress": "text-yellow-800 bg-yellow-100",
    completed: "text-green-800 bg-green-100",
    cancelled: "text-gray-800 bg-gray-100",
  };
  return colors[status.toLowerCase()] || "text-gray-800 bg-gray-100";
}
