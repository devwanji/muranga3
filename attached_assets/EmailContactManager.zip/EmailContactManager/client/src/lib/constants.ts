// Site information
export const SITE_NAME = "Murang'a Marketplace";
export const SITE_DESCRIPTION = "Connecting local businesses with customers in Murang'a County";
export const SITE_CONTACT_EMAIL = "murangamarketplace@gmail.com";
export const SITE_CONTACT_PHONE = "0714 092 658";
export const SITE_LOCATION = "Murang'a Town, Kenya";

// Subscription prices
export const MONTHLY_PRICE = 200; // KSh
export const YEARLY_PRICE = 3000; // KSh

// Business categories
export const BUSINESS_CATEGORIES = [
  { id: "restaurants", name: "Restaurants", icon: "utensils" },
  { id: "retail", name: "Retail Shops", icon: "shopping-bag" },
  { id: "repair", name: "Repair Services", icon: "tools" },
  { id: "agriculture", name: "Agriculture", icon: "tractor" },
  { id: "professional", name: "Professional Services", icon: "briefcase" },
  { id: "transport", name: "Transport", icon: "truck" },
  { id: "food", name: "Food & Restaurants", icon: "utensils" },
  { id: "other", name: "Other Services", icon: "store" },
];

// Service request status options
export const REQUEST_STATUSES = {
  NEW: "new",
  SEEN: "seen",
  IN_PROGRESS: "in progress",
  COMPLETED: "completed",
  CANCELLED: "cancelled",
};

// Business status options
export const BUSINESS_STATUSES = {
  ACTIVE: "active",
  PENDING: "pending",
  EXPIRED: "expired",
};

// User roles
export const USER_ROLES = {
  ADMIN: "admin",
  BUSINESS: "business",
  CUSTOMER: "customer",
};

// Local storage keys
export const STORAGE_KEYS = {
  BUSINESSES: "muranga_marketplace_businesses",
  SERVICE_REQUESTS: "muranga_marketplace_service_requests",
  CURRENT_USER: "muranga_marketplace_current_user",
  THEME: "muranga_marketplace_theme",
};
