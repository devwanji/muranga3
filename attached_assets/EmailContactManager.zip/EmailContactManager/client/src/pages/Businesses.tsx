import { BusinessCard } from "@/components/BusinessCard";
import { CategoryCard } from "@/components/CategoryCard";
import { getBusinesses } from "@/lib/store";
import { categories } from "@shared/schema";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Businesses() {
  const [businesses, setBusinesses] = useState(getBusinesses());
  const [filteredBusinesses, setFilteredBusinesses] = useState(businesses);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("newest");

  // Re-fetch businesses when component mounts
  useEffect(() => {
    setBusinesses(getBusinesses());
  }, []);

  // Filter and sort businesses when dependencies change
  useEffect(() => {
    let result = [...businesses];
    
    // Filter by category if selected
    if (activeCategory) {
      result = result.filter(business => business.category === activeCategory);
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(business => 
        business.name.toLowerCase().includes(query) || 
        business.description.toLowerCase().includes(query) ||
        business.location.toLowerCase().includes(query)
      );
    }
    
    // Sort businesses
    if (sortOption === "newest") {
      result.sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime());
    } else if (sortOption === "oldest") {
      result.sort((a, b) => new Date(a.registrationDate).getTime() - new Date(b.registrationDate).getTime());
    } else if (sortOption === "rating") {
      result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    }
    
    setFilteredBusinesses(result);
  }, [businesses, activeCategory, searchQuery, sortOption]);

  const handleCategoryClick = (categoryId: string) => {
    setActiveCategory(activeCategory === categoryId ? null : categoryId);
  };

  return (
    <div className="py-12 bg-neutral">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-darkText mb-4">Browse Businesses</h1>
          <p className="text-gray-600">Find and connect with local businesses in Murang'a County</p>
        </div>
        
        {/* Filter and Search */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <Input
                type="text"
                id="search"
                placeholder="Search businesses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="sort" className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger id="sort">
                  <SelectValue placeholder="Sort businesses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Categories */}
        <div className="mb-12">
          <h2 className="text-xl font-bold text-darkText mb-4">Categories</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <CategoryCard
                key={category.id}
                id={category.id}
                name={category.name}
                onClick={() => handleCategoryClick(category.id)}
              />
            ))}
          </div>
        </div>
        
        {/* Business Listings */}
        <div>
          <h2 className="text-xl font-bold text-darkText mb-4">
            {activeCategory 
              ? `${categories.find(c => c.id === activeCategory)?.name} Businesses` 
              : "All Businesses"}
            {searchQuery && ` matching "${searchQuery}"`}
            <span className="text-base font-normal text-gray-500 ml-2">({filteredBusinesses.length} found)</span>
          </h2>
          
          {filteredBusinesses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredBusinesses.map((business) => (
                <BusinessCard key={business.id} business={business} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow">
              <i className="fas fa-store text-gray-300 text-5xl mb-4"></i>
              <h3 className="text-xl font-medium text-gray-800 mb-2">No businesses found</h3>
              <p className="text-gray-600">
                {searchQuery 
                  ? "Try adjusting your search terms or filters"
                  : "There are no businesses in this category yet"}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
