import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getCurrentUser, getBusinessById, getBusinessStats, getServiceRequestsByBusiness, StoredServiceRequest, updateServiceRequestStatus } from "@/lib/store";
import { formatDate, getStatusColor } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function BusinessDashboard() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const currentUser = getCurrentUser();
  const [requests, setRequests] = useState<StoredServiceRequest[]>([]);
  const [stats, setStats] = useState({ newRequestCount: 0, totalRequestCount: 0, subscriptionType: 'monthly', expiryDate: '' });
  const businessId = currentUser?.businessId || 'b1'; // Default to b1 for demo

  useEffect(() => {
    // Check if user is logged in as a business owner
    if (!currentUser || currentUser.role !== 'business') {
      toast({
        title: "Access Denied",
        description: "You must be logged in as a business owner to view this page.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    // Load business data and service requests
    const businessRequests = getServiceRequestsByBusiness(businessId);
    const businessStats = getBusinessStats(businessId);
    
    setRequests(businessRequests);
    setStats(businessStats);
  }, [businessId, currentUser, navigate, toast]);

  // Handle request status update
  const handleStatusUpdate = (requestId: string, newStatus: StoredServiceRequest['status']) => {
    updateServiceRequestStatus(requestId, newStatus);
    
    // Update local state to reflect the change
    setRequests(requests.map(req => 
      req.id === requestId ? { ...req, status: newStatus, seen: true } : req
    ));
    
    // Update stats since we may have marked a new request as seen
    setStats({
      ...stats,
      newRequestCount: stats.newRequestCount - (
        requests.find(req => req.id === requestId)?.status === 'new' ? 1 : 0
      )
    });
    
    toast({
      title: "Request Updated",
      description: `The request status has been updated to ${newStatus}.`,
      variant: "default",
    });
  };

  // Get business details
  const business = getBusinessById(businessId);

  return (
    <section className="py-12 bg-neutral">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-start mb-8">
          <div className="md:flex-1">
            <h1 className="text-3xl font-bold text-darkText mb-2">{business?.name || 'Business'} Dashboard</h1>
            <p className="text-gray-600">{business?.category || 'Category'}</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button className="bg-primary hover:bg-secondary text-white">
              Edit Business Profile
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-darkText">New Requests</h3>
                {stats.newRequestCount > 0 && (
                  <Badge variant="destructive" className="bg-error text-white">
                    {stats.newRequestCount} New
                  </Badge>
                )}
              </div>
              <div className="flex items-center">
                <div className="bg-primary/10 rounded-full p-3 mr-4">
                  <i className="fas fa-bell text-primary text-xl"></i>
                </div>
                <div>
                  <p className="text-2xl font-bold text-darkText">{stats.newRequestCount}</p>
                  <p className="text-gray-500 text-sm">Unread requests</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white">
            <CardContent className="p-6">
              <h3 className="font-semibold text-darkText mb-4">Total Requests</h3>
              <div className="flex items-center">
                <div className="bg-secondary/10 rounded-full p-3 mr-4">
                  <i className="fas fa-clipboard-list text-secondary text-xl"></i>
                </div>
                <div>
                  <p className="text-2xl font-bold text-darkText">{stats.totalRequestCount}</p>
                  <p className="text-gray-500 text-sm">All-time requests</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white">
            <CardContent className="p-6">
              <h3 className="font-semibold text-darkText mb-4">Subscription Status</h3>
              <div className="flex items-center">
                <div className="bg-success/10 rounded-full p-3 mr-4">
                  <i className="fas fa-check-circle text-success text-xl"></i>
                </div>
                <div>
                  <p className="text-lg font-medium text-darkText">
                    Active ({stats.subscriptionType === 'monthly' ? 'Monthly' : 'Yearly'})
                  </p>
                  <p className="text-gray-500 text-sm">
                    Renews on: {formatDate(stats.expiryDate)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card className="bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="font-semibold text-darkText">Customer Requests</h3>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</TableHead>
                  <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</TableHead>
                  <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</TableHead>
                  <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
                  <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requests.length > 0 ? (
                  requests.map((request) => (
                    <TableRow 
                      key={request.id} 
                      className={!request.seen ? 'bg-red-50' : ''}
                    >
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="text-sm font-medium text-darkText">{request.customerName}</div>
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{request.description}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{formatDate(request.timestamp)}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getStatusColor(request.status)}>
                          {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          {request.status === 'new' && (
                            <>
                              <Button 
                                variant="link" 
                                className="text-primary hover:text-secondary p-0"
                                onClick={() => handleStatusUpdate(request.id, 'in progress')}
                              >
                                Mark In Progress
                              </Button>
                            </>
                          )}
                          {request.status === 'in progress' && (
                            <Button 
                              variant="link" 
                              className="text-primary hover:text-secondary p-0"
                              onClick={() => handleStatusUpdate(request.id, 'completed')}
                            >
                              Mark Completed
                            </Button>
                          )}
                          {request.status === 'new' && (
                            <Button 
                              variant="link" 
                              className="text-primary hover:text-secondary p-0"
                              onClick={() => handleStatusUpdate(request.id, 'seen')}
                            >
                              Mark as Seen
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                      No service requests yet
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
            <Link href="#">
              <a className="text-sm text-primary hover:text-secondary font-medium">View all requests</a>
            </Link>
          </div>
        </Card>
      </div>
    </section>
  );
}
