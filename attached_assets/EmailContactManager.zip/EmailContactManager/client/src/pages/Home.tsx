import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { categories } from "@shared/schema";
import { CategoryCard } from "@/components/CategoryCard";
import { BusinessCard } from "@/components/BusinessCard";
import { getBusinesses } from "@/lib/store";
import { useEffect, useState } from "react";

export default function Home() {
  const [businesses, setBusinesses] = useState(getBusinesses());

  // Re-fetch businesses when mounting component
  useEffect(() => {
    setBusinesses(getBusinesses());
  }, []);

  return (
    <>
      {/* Home Section */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:flex items-center justify-between">
            <div className="lg:w-1/2 mb-10 lg:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold text-darkText mb-4">Murang'a Marketplace</h1>
              <p className="text-lg text-gray-600 mb-6">
                Connect with local businesses and service providers in Murang'a County. Find the services you need or register your business to reach more customers.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/request-service">
                  <Button variant="default" className="bg-primary hover:bg-secondary text-white px-6 py-3 inline-flex items-center justify-center">
                    Request a Service
                    <i className="fas fa-arrow-right ml-2"></i>
                  </Button>
                </Link>
                <Link href="/register-business">
                  <Button variant="outline" className="text-primary bg-white hover:bg-neutral px-6 py-3 inline-flex items-center justify-center ring-1 ring-primary">
                    Register Your Business
                    <i className="fas fa-store ml-2"></i>
                  </Button>
                </Link>
              </div>
            </div>
            <div className="lg:w-5/12">
              <img 
                src="https://images.unsplash.com/photo-1621944190310-e3cca1564bd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Kenyan marketplace scene" 
                className="rounded-xl shadow-lg w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Business Categories */}
      <section className="py-12 bg-neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-darkText mb-2">Popular Business Categories</h2>
            <p className="text-gray-600">Find the services you need from our wide range of local businesses</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category) => (
              <CategoryCard
                key={category.id}
                id={category.id}
                name={category.name}
                onClick={() => {}}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Businesses */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-darkText mb-2">Featured Businesses</h2>
            <p className="text-gray-600">Discover top-rated local businesses in Murang'a</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {businesses.slice(0, 3).map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Link href="/businesses">
              <Button variant="default" className="bg-primary hover:bg-secondary text-white px-6 py-3 inline-flex items-center justify-center">
                View All Businesses
                <i className="fas fa-arrow-right ml-2"></i>
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
