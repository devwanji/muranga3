import { ServiceRequestForm } from "@/components/ServiceRequestForm";

export default function RequestService() {
  return (
    <section className="py-12 md:py-16 bg-neutral">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-darkText mb-2">Request a Service</h1>
          <p className="text-gray-600">Fill out the form below to connect with local businesses that can help you</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
          <ServiceRequestForm />
        </div>
      </div>
    </section>
  );
}
