import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getCurrentUser, getAdminStats, getRecentBusinesses, getRecentRequests } from "@/lib/store";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const currentUser = getCurrentUser();
  const [stats, setStats] = useState({ businessCount: 0, requestCount: 0, revenue: 0, expiredCount: 0 });
  const [recentBusinesses, setRecentBusinesses] = useState<any[]>([]);
  const [recentRequests, setRecentRequests] = useState<any[]>([]);

  useEffect(() => {
    // Check if user is logged in as admin
    if (!currentUser || currentUser.role !== 'admin') {
      toast({
        title: "Access Denied",
        description: "You must be logged in as an administrator to view this page.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    // Load admin dashboard data
    setStats(getAdminStats());
    setRecentBusinesses(getRecentBusinesses());
    setRecentRequests(getRecentRequests());
  }, [currentUser, navigate, toast]);

  return (
    <section className="py-12 bg-neutral">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-darkText">Admin Dashboard</h1>
          <div className="text-sm text-gray-600">
            Welcome, <span className="font-medium">{currentUser?.name || 'Administrator'}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-primary/10 rounded-full p-3 mr-4">
                  <i className="fas fa-store text-primary text-xl"></i>
                </div>
                <div>
                  <p className="text-2xl font-bold text-darkText">{stats.businessCount}</p>
                  <p className="text-gray-500 text-sm">Registered Businesses</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-secondary/10 rounded-full p-3 mr-4">
                  <i className="fas fa-clipboard-list text-secondary text-xl"></i>
                </div>
                <div>
                  <p className="text-2xl font-bold text-darkText">{stats.requestCount}</p>
                  <p className="text-gray-500 text-sm">Service Requests</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-success/10 rounded-full p-3 mr-4">
                  <i className="fas fa-money-bill-wave text-success text-xl"></i>
                </div>
                <div>
                  <p className="text-2xl font-bold text-darkText">{formatCurrency(stats.revenue)}</p>
                  <p className="text-gray-500 text-sm">Revenue (KSh)</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-error/10 rounded-full p-3 mr-4">
                  <i className="fas fa-user-times text-error text-xl"></i>
                </div>
                <div>
                  <p className="text-2xl font-bold text-darkText">{stats.expiredCount}</p>
                  <p className="text-gray-500 text-sm">Expired Subscriptions</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="bg-white overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="font-semibold text-darkText">Recent Businesses</h3>
              <Button variant="link" className="text-primary hover:text-secondary text-sm p-0">View all</Button>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Business</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentBusinesses.map((business) => (
                    <TableRow key={business.id}>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-darkText">{business.name}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{business.category}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getStatusColor(business.status)}>
                          {business.status.charAt(0).toUpperCase() + business.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <Button variant="link" className="text-primary hover:text-secondary p-0">View</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
          
          <Card className="bg-white overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="font-semibold text-darkText">Recent Service Requests</h3>
              <Button variant="link" className="text-primary hover:text-secondary text-sm p-0">View all</Button>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Business</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-darkText">{request.customerName}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{request.businessId}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{formatDate(request.timestamp)}</div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getStatusColor(request.status)}>
                          {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </div>
        
        <Card className="bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="font-semibold text-darkText">Subscription Overview</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-medium text-gray-500 mb-3">Subscription Type</h4>
                <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <div className="flex justify-center mb-2">
                      <div className="w-32 h-32 rounded-full border-8 border-primary relative">
                        <div className="w-32 h-32 rounded-full border-8 border-gray-200 absolute top-0 left-0 border-t-transparent border-l-transparent transform -rotate-45"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div>
                            <p className="text-2xl font-bold text-darkText">75%</p>
                            <p className="text-xs text-gray-500">Monthly</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-primary rounded-full mr-2"></span>
                        <span className="text-sm text-gray-600">Monthly: 18 businesses</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-gray-300 rounded-full mr-2"></span>
                        <span className="text-sm text-gray-600">Yearly: 6 businesses</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500 mb-3">Revenue by Month (KSh)</h4>
                <div className="h-64 bg-gray-50 rounded-lg p-4">
                  <div className="h-full flex items-end justify-between">
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '30%' }}></div>
                      <span className="text-xs mt-2">Jan</span>
                    </div>
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '45%' }}></div>
                      <span className="text-xs mt-2">Feb</span>
                    </div>
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '40%' }}></div>
                      <span className="text-xs mt-2">Mar</span>
                    </div>
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '50%' }}></div>
                      <span className="text-xs mt-2">Apr</span>
                    </div>
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '65%' }}></div>
                      <span className="text-xs mt-2">May</span>
                    </div>
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '75%' }}></div>
                      <span className="text-xs mt-2">Jun</span>
                    </div>
                    <div className="w-1/12 flex flex-col items-center">
                      <div className="bg-primary w-full" style={{ height: '90%' }}></div>
                      <span className="text-xs mt-2">Jul</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}
