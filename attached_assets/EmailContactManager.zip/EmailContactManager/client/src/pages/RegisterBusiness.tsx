import { BusinessRegistrationForm } from "@/components/BusinessRegistrationForm";

export default function RegisterBusiness() {
  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex items-center gap-12">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <div className="text-left mb-6">
              <h2 className="text-3xl font-bold text-darkText mb-2">Register Your Business</h2>
              <p className="text-gray-600">Join our marketplace to reach more customers and grow your business in Murang'a County</p>
            </div>
            
            <div className="bg-neutral p-6 rounded-lg mb-8">
              <h3 className="text-xl font-semibold text-darkText mb-4">Subscription Plans</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-5 rounded-lg shadow-md border border-gray-200 hover:border-primary transition-all">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-semibold text-lg">Monthly</h4>
                    <span className="bg-green-100 text-primary text-sm px-3 py-1 rounded-full">Popular</span>
                  </div>
                  <p className="text-3xl font-bold text-darkText mb-1">Ksh 200<span className="text-sm font-normal text-gray-500">/month</span></p>
                  <p className="text-gray-600 text-sm mb-4">Perfect for testing the platform</p>
                  <ul className="mb-6 space-y-2">
                    <li className="flex items-center text-sm">
                      <i className="fas fa-check text-success mr-2"></i>
                      <span>Business profile</span>
                    </li>
                    <li className="flex items-center text-sm">
                      <i className="fas fa-check text-success mr-2"></i>
                      <span>Customer request notifications</span>
                    </li>
                    <li className="flex items-center text-sm">
                      <i className="fas fa-check text-success mr-2"></i>
                      <span>Business dashboard</span>
                    </li>
                  </ul>
                </div>
                
                <div className="bg-white p-5 rounded-lg shadow-md border border-primary transition-all">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-semibold text-lg">Annual</h4>
                    <span className="bg-primary text-white text-sm px-3 py-1 rounded-full">Save 25%</span>
                  </div>
                  <p className="text-3xl font-bold text-darkText mb-1">Ksh 3,000<span className="text-sm font-normal text-gray-500">/year</span></p>
                  <p className="text-gray-600 text-sm mb-4">Best value for established businesses</p>
                  <ul className="mb-6 space-y-2">
                    <li className="flex items-center text-sm">
                      <i className="fas fa-check text-success mr-2"></i>
                      <span>All monthly features</span>
                    </li>
                    <li className="flex items-center text-sm">
                      <i className="fas fa-check text-success mr-2"></i>
                      <span>Featured in search results</span>
                    </li>
                    <li className="flex items-center text-sm">
                      <i className="fas fa-check text-success mr-2"></i>
                      <span>Business analytics</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            
            <img 
              src="https://images.unsplash.com/photo-1558403194-611308249627?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500" 
              alt="Local business professionals" 
              className="rounded-lg shadow-md w-full h-auto object-cover"
            />
          </div>
          
          <div className="lg:w-1/2">
            <div className="bg-neutral rounded-lg shadow-md p-6 md:p-8">
              <BusinessRegistrationForm />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
