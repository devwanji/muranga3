import { Route, Switch } from "wouter";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import Home from "@/pages/Home";
import Businesses from "@/pages/Businesses";
import RequestService from "@/pages/RequestService";
import RegisterBusiness from "@/pages/RegisterBusiness";
import BusinessDashboard from "@/pages/BusinessDashboard";
import AdminDashboard from "@/pages/AdminDashboard";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";
import { initializeStore } from "./lib/store";

function App() {
  // Initialize store with demo data on first load
  useEffect(() => {
    initializeStore();
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/businesses" component={Businesses} />
          <Route path="/request-service" component={RequestService} />
          <Route path="/register-business" component={RegisterBusiness} />
          <Route path="/business-dashboard" component={BusinessDashboard} />
          <Route path="/admin-dashboard" component={AdminDashboard} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

export default App;
