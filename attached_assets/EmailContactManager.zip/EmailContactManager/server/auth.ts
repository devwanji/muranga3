import { NextFunction, Request, Response } from "express";
import { storage } from "./storage";
import session from "express-session";

// Extend the session interface to include our user ID
declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

// Define a custom type that adds user to the Express Request
declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

// Authentication middleware using session
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  // Check for user ID in session
  if (req.session && req.session.userId) {
    try {
      const user = await storage.getUser(req.session.userId);
      if (user) {
        req.user = user;
        return next();
      }
    } catch (error) {
      console.error("Authentication error:", error);
    }
  }
  
  return res.status(401).json({ message: "Not authenticated" });
};

// Role-based access control middleware
export const authorize = (roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Not authorized" });
    }
    
    next();
  };
};

// Admin only middleware
export const adminOnly = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Admin access required" });
  }
  
  next();
};

// Business owner only middleware
export const businessOwnerOnly = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  if (req.user.role !== "business") {
    return res.status(403).json({ message: "Business owner access required" });
  }
  
  next();
};

// Login handler
export const login = async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    
    // Validate credentials
    const user = await storage.validateUserCredentials(username, password);
    
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    
    // Store user ID in session
    if (req.session) {
      req.session.userId = user.id;
    }
    
    // Remove password from response
    const { password: _, ...userWithoutPassword } = user;
    
    return res.status(200).json({
      message: "Login successful",
      user: userWithoutPassword
    });
  } catch (error) {
    console.error("Login error:", error);
    return res.status(400).json({ message: "Invalid request data" });
  }
};

// Register user
export const register = async (req: Request, res: Response) => {
  try {
    const { username, password, email, firstName, lastName, role = "customer" } = req.body;
    
    // Check if username already exists
    const existingUser = await storage.getUserByUsername(username);
    if (existingUser) {
      return res.status(409).json({ message: "Username already exists" });
    }
    
    // Check if email already exists
    if (email) {
      const existingUserByEmail = await storage.getUserByEmail(email);
      if (existingUserByEmail) {
        return res.status(409).json({ message: "Email already exists" });
      }
    }
    
    // Create the user
    const user = await storage.createUser({
      username,
      password,
      email,
      firstName,
      lastName,
      role
    });
    
    // Remove password from response
    const { password: _, ...userWithoutPassword } = user;
    
    return res.status(201).json({
      message: "User registered successfully",
      user: userWithoutPassword
    });
  } catch (error) {
    console.error("Registration error:", error);
    return res.status(400).json({ message: "Invalid request data" });
  }
};

// Logout handler
export const logout = (req: Request, res: Response) => {
  if (req.session) {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Failed to logout" });
      }
      
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  } else {
    return res.status(200).json({ message: "No active session" });
  }
};

// Get current user
export const getCurrentUser = async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  // Remove password from response
  const { password, ...userWithoutPassword } = req.user;
  
  return res.status(200).json(userWithoutPassword);
};