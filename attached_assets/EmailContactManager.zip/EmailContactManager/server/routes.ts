import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { 
  authenticate, 
  authorize, 
  adminOnly, 
  businessOwnerOnly, 
  getCurrentUser,
  login,
  register,
  logout
} from "./auth";
import { insertBusinessSchema, insertServiceRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // HTTP Server
  const httpServer = createServer(app);
  
  // WebSocket Server for real-time notifications
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  
  // WebSocket connection handling for real-time notifications
  const clients = new Map();
  
  wss.on("connection", (socket) => {
    socket.on("message", (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // If user ID is provided, associate the socket with that user
        if (data.type === "auth" && data.userId) {
          clients.set(data.userId, socket);
          socket.send(JSON.stringify({ type: "auth_success" }));
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    });
    
    socket.on("close", () => {
      // Remove socket from clients map when disconnected
      clients.forEach((clientSocket, userId) => {
        if (clientSocket === socket) {
          clients.delete(userId);
        }
      });
    });
  });
  
  // Helper function to send notifications to connected clients
  const sendNotification = (userId: string, notification: any) => {
    const socket = clients.get(userId);
    if (socket && socket.readyState === 1) { // 1 = OPEN state for WebSockets
      socket.send(JSON.stringify({
        type: "notification",
        data: notification
      }));
    }
  };

  // ===== Authentication Routes =====
  // Traditional username/password authentication
  app.post("/api/login", login);
  app.post("/api/register", register);
  app.post("/api/logout", logout);
  
  // Get current authenticated user
  app.get("/api/user", authenticate, getCurrentUser);
  
  // ===== Business Routes =====
  
  // Get all businesses (public)
  app.get("/api/businesses", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const businesses = await storage.getAllBusinesses(status);
      res.json(businesses);
    } catch (error) {
      console.error("Error fetching businesses:", error);
      res.status(500).json({ message: "Failed to fetch businesses" });
    }
  });
  
  // Get businesses by category (public)
  app.get("/api/businesses/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const businesses = await storage.getBusinessesByCategory(category);
      res.json(businesses);
    } catch (error) {
      console.error("Error fetching businesses by category:", error);
      res.status(500).json({ message: "Failed to fetch businesses by category" });
    }
  });
  
  // Get business by ID (public)
  app.get("/api/businesses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid business ID" });
      }
      
      const business = await storage.getBusiness(id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      res.json(business);
    } catch (error) {
      console.error("Error fetching business:", error);
      res.status(500).json({ message: "Failed to fetch business" });
    }
  });
  
  // Get businesses for current business owner
  app.get("/api/my-businesses", authenticate, businessOwnerOnly, async (req: Request, res: Response) => {
    try {
      const businesses = await storage.getBusinessesByOwner(req.user.id);
      res.json(businesses);
    } catch (error) {
      console.error("Error fetching business owner's businesses:", error);
      res.status(500).json({ message: "Failed to fetch businesses" });
    }
  });
  
  // Register new business
  app.post("/api/businesses", authenticate, async (req: Request, res: Response) => {
    try {
      const businessData = insertBusinessSchema.parse(req.body);
      
      // Set owner ID from authenticated user
      const business = await storage.createBusiness({
        ...businessData,
        ownerId: req.user.id
      });
      
          // For a real application, you would create notifications for all admin users
      // Here we'll create a placeholder notification - in a real system you would
      // look up all admin users and notify each one
      if (req.user.role === "admin") {
        await storage.createNotification({
          userId: req.user.id,
          type: "admin_action",
          title: "New Business Registration",
          message: `${business.name} has registered and is waiting for approval.`,
          relatedId: business.id.toString(),
          read: false
        });
      }
      
      res.status(201).json(business);
    } catch (error) {
      console.error("Error creating business:", error);
      res.status(400).json({ message: "Invalid business data" });
    }
  });
  
  // Update business status (admin only)
  app.patch("/api/businesses/:id/status", authenticate, adminOnly, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid business ID" });
      }
      
      const { status } = req.body;
      if (!status || !["pending", "active", "expired"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const business = await storage.getBusiness(id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      const updatedBusiness = await storage.updateBusiness(id, { status });
      
      // Create notification for business owner about status change
      if (updatedBusiness) {
        await storage.createNotification({
          userId: updatedBusiness.ownerId,
          type: "admin_action",
          title: "Business Status Update",
          message: `Your business ${updatedBusiness.name} status has been updated to ${status}.`,
          relatedId: id.toString(),
          read: false
        });
        
        // Send real-time notification
        sendNotification(updatedBusiness.ownerId, {
          title: "Business Status Update",
          message: `Your business ${updatedBusiness.name} status has been updated to ${status}.`
        });
      }
      
      res.json(updatedBusiness);
    } catch (error) {
      console.error("Error updating business status:", error);
      res.status(500).json({ message: "Failed to update business status" });
    }
  });
  
  // Delete business (admin only)
  app.delete("/api/businesses/:id", authenticate, adminOnly, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid business ID" });
      }
      
      const business = await storage.getBusiness(id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      const businessOwnerId = business.ownerId;
      const businessName = business.name;
      
      const deleted = await storage.deleteBusiness(id);
      
      if (deleted) {
        // Create notification for business owner about deletion
        await storage.createNotification({
          userId: businessOwnerId,
          type: "admin_action",
          title: "Business Deleted",
          message: `Your business ${businessName} has been deleted by an administrator.`,
          read: false
        });
        
        // Send real-time notification
        sendNotification(businessOwnerId, {
          title: "Business Deleted",
          message: `Your business ${businessName} has been deleted by an administrator.`
        });
        
        return res.status(200).json({ message: "Business deleted successfully" });
      } else {
        return res.status(500).json({ message: "Failed to delete business" });
      }
    } catch (error) {
      console.error("Error deleting business:", error);
      res.status(500).json({ message: "Failed to delete business" });
    }
  });
  
  // ===== Service Request Routes =====
  
  // Submit service request
  app.post("/api/service-requests", async (req: Request, res: Response) => {
    try {
      const { businessId, ...requestData } = req.body;
      
      if (!businessId) {
        return res.status(400).json({ message: "Business ID is required" });
      }
      
      const parsedBusinessId = parseInt(businessId.toString());
      if (isNaN(parsedBusinessId)) {
        return res.status(400).json({ message: "Invalid business ID" });
      }
      
      const business = await storage.getBusiness(parsedBusinessId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      const validatedRequestData = insertServiceRequestSchema.parse(requestData);
      const serviceRequest = await storage.createServiceRequest(validatedRequestData, parsedBusinessId);
      
      // Create notification for business owner
      await storage.createNotification({
        userId: business.ownerId,
        type: "service_request",
        title: "New Service Request",
        message: `You have received a new service request from ${serviceRequest.customerName}.`,
        relatedId: serviceRequest.id.toString(),
        read: false
      });
      
      // Send real-time notification
      sendNotification(business.ownerId, {
        title: "New Service Request",
        message: `You have received a new service request from ${serviceRequest.customerName}.`
      });
      
      res.status(201).json(serviceRequest);
    } catch (error) {
      console.error("Error creating service request:", error);
      res.status(400).json({ message: "Invalid service request data" });
    }
  });
  
  // Get service requests for business
  app.get("/api/businesses/:id/service-requests", authenticate, async (req: Request, res: Response) => {
    try {
      const businessId = parseInt(req.params.id);
      if (isNaN(businessId)) {
        return res.status(400).json({ message: "Invalid business ID" });
      }
      
      const business = await storage.getBusiness(businessId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      // Only allow the business owner or admin to access service requests
      if (req.user.role !== "admin" && business.ownerId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to view these service requests" });
      }
      
      const serviceRequests = await storage.getServiceRequestsByBusiness(businessId);
      res.json(serviceRequests);
    } catch (error) {
      console.error("Error fetching service requests:", error);
      res.status(500).json({ message: "Failed to fetch service requests" });
    }
  });
  
  // Update service request status
  app.patch("/api/service-requests/:id/status", authenticate, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid service request ID" });
      }
      
      const { status } = req.body;
      if (!status || !["new", "seen", "in progress", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const serviceRequest = await storage.getServiceRequest(id);
      if (!serviceRequest) {
        return res.status(404).json({ message: "Service request not found" });
      }
      
      const business = await storage.getBusiness(serviceRequest.businessId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      // Only allow the business owner or admin to update service requests
      if (req.user.role !== "admin" && business.ownerId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this service request" });
      }
      
      const updatedServiceRequest = await storage.updateServiceRequestStatus(id, status);
      res.json(updatedServiceRequest);
    } catch (error) {
      console.error("Error updating service request:", error);
      res.status(500).json({ message: "Failed to update service request" });
    }
  });
  
  // ===== Notification Routes =====
  
  // Get current user's notifications
  app.get("/api/notifications", authenticate, async (req: Request, res: Response) => {
    try {
      const readParam = req.query.read;
      let readStatus: boolean | undefined = undefined;
      
      if (readParam === "true") {
        readStatus = true;
      } else if (readParam === "false") {
        readStatus = false;
      }
      
      const notifications = await storage.getNotifications(req.user.id, readStatus);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });
  
  // Mark notification as read
  app.patch("/api/notifications/:id/read", authenticate, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notification ID" });
      }
      
      const success = await storage.markNotificationAsRead(id);
      
      if (success) {
        res.json({ message: "Notification marked as read" });
      } else {
        res.status(404).json({ message: "Notification not found" });
      }
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  return httpServer;
}
