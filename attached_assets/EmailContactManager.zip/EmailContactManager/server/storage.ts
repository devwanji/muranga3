import { 
  users, 
  businesses, 
  serviceRequests, 
  notifications,
  type User, 
  type UpsertUser, 
  type InsertUser,
  type Business,
  type InsertBusiness,
  type ServiceRequest,
  type InsertServiceRequest,
  type Notification,
  type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import bcrypt from "bcryptjs";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(userData: InsertUser): Promise<User>;
  upsertUser(userData: UpsertUser): Promise<User>;
  validateUserCredentials(username: string, password: string): Promise<User | null>;
  
  // Business operations
  getBusiness(id: number): Promise<Business | undefined>;
  getBusinessesByOwner(ownerId: string): Promise<Business[]>;
  getBusinessesByCategory(category: string): Promise<Business[]>;
  getAllBusinesses(status?: string): Promise<Business[]>;
  createBusiness(businessData: InsertBusiness): Promise<Business>;
  updateBusiness(id: number, businessData: Partial<Business>): Promise<Business | null>;
  deleteBusiness(id: number): Promise<boolean>;
  
  // Service Request operations
  getServiceRequest(id: number): Promise<ServiceRequest | undefined>;
  getServiceRequestsByBusiness(businessId: number): Promise<ServiceRequest[]>;
  createServiceRequest(requestData: InsertServiceRequest, businessId: number): Promise<ServiceRequest>;
  updateServiceRequestStatus(id: number, status: string, seen?: boolean): Promise<ServiceRequest | null>;
  
  // Notification operations
  getNotifications(userId: string, read?: boolean): Promise<Notification[]>;
  createNotification(notificationData: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!email) return undefined;
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    if (!username) return undefined;
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    // Hash the password before storing
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        password: hashedPassword
      })
      .returning();
    
    return user;
  }
  
  async validateUserCredentials(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return null;
    
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // For Replit Auth integration
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    
    return user;
  }

  // Business operations
  async getBusiness(id: number): Promise<Business | undefined> {
    const [business] = await db
      .select()
      .from(businesses)
      .where(eq(businesses.id, id));
    
    return business;
  }

  async getBusinessesByOwner(ownerId: string): Promise<Business[]> {
    return db
      .select()
      .from(businesses)
      .where(eq(businesses.ownerId, ownerId))
      .orderBy(desc(businesses.createdAt));
  }

  async getBusinessesByCategory(category: string): Promise<Business[]> {
    return db
      .select()
      .from(businesses)
      .where(and(
        eq(businesses.category, category),
        eq(businesses.status, "active")
      ))
      .orderBy(desc(businesses.createdAt));
  }

  async getAllBusinesses(status?: string): Promise<Business[]> {
    if (status) {
      return db
        .select()
        .from(businesses)
        .where(eq(businesses.status, status))
        .orderBy(desc(businesses.createdAt));
    }
    
    return db
      .select()
      .from(businesses)
      .orderBy(desc(businesses.createdAt));
  }

  async createBusiness(businessData: InsertBusiness): Promise<Business> {
    const [business] = await db
      .insert(businesses)
      .values({
        ...businessData,
        registrationDate: new Date(),
        expiryDate: new Date(new Date().setMonth(new Date().getMonth() + (businessData.subscriptionPlan === "yearly" ? 12 : 1)))
      })
      .returning();
    
    return business;
  }

  async updateBusiness(id: number, businessData: Partial<Business>): Promise<Business | null> {
    const [business] = await db
      .update(businesses)
      .set({
        ...businessData,
        updatedAt: new Date()
      })
      .where(eq(businesses.id, id))
      .returning();
    
    return business || null;
  }

  async deleteBusiness(id: number): Promise<boolean> {
    try {
      // First delete all service requests related to this business
      await db
        .delete(serviceRequests)
        .where(eq(serviceRequests.businessId, id));
      
      // Then delete the business
      const [deletedBusiness] = await db
        .delete(businesses)
        .where(eq(businesses.id, id))
        .returning({ id: businesses.id });
      
      return !!deletedBusiness;
    } catch (error) {
      console.error("Error deleting business:", error);
      return false;
    }
  }

  // Service Request operations
  async getServiceRequest(id: number): Promise<ServiceRequest | undefined> {
    const [request] = await db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.id, id));
    
    return request;
  }

  async getServiceRequestsByBusiness(businessId: number): Promise<ServiceRequest[]> {
    return db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.businessId, businessId))
      .orderBy(desc(serviceRequests.createdAt));
  }

  async createServiceRequest(requestData: InsertServiceRequest, businessId: number): Promise<ServiceRequest> {
    const [request] = await db
      .insert(serviceRequests)
      .values({
        ...requestData,
        businessId,
        timestamp: new Date(),
      })
      .returning();
    
    return request;
  }

  async updateServiceRequestStatus(id: number, status: string, seen = true): Promise<ServiceRequest | null> {
    const [request] = await db
      .update(serviceRequests)
      .set({
        status,
        seen,
        updatedAt: new Date()
      })
      .where(eq(serviceRequests.id, id))
      .returning();
    
    return request || null;
  }

  // Notification operations
  async getNotifications(userId: string, read?: boolean): Promise<Notification[]> {
    if (read !== undefined) {
      return db
        .select()
        .from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.read, read)
        ))
        .orderBy(desc(notifications.createdAt));
    }
    
    return db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values(notificationData)
      .returning();
    
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<boolean> {
    const [notification] = await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning({ id: notifications.id });
    
    return !!notification;
  }
}

export const storage = new DatabaseStorage();