import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, varchar, index, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const categories = [
  { id: "restaurants", name: "Restaurants", icon: "utensils" },
  { id: "retail", name: "Retail Shops", icon: "shopping-bag" },
  { id: "repair", name: "Repair Services", icon: "tools" },
  { id: "agriculture", name: "Agriculture", icon: "tractor" },
  { id: "professional", name: "Professional", icon: "briefcase" },
  { id: "transport", name: "Transport", icon: "truck" },
];

// User roles enum
export const userRoleEnum = pgEnum("user_role", ["admin", "business", "customer"]);

// For session storage with Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username").notNull().unique(),
  password: varchar("password").notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default("customer"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userRelations = relations(users, ({ many }) => ({
  businesses: many(businesses),
  notifications: many(notifications),
}));

export const businesses = pgTable("businesses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  contactPerson: text("contact_person").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  subscriptionPlan: text("subscription_plan").notNull(),
  registrationDate: timestamp("registration_date").notNull(),
  expiryDate: timestamp("expiry_date").notNull(),
  status: text("status").notNull().default("pending"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const businessRelations = relations(businesses, ({ one, many }) => ({
  owner: one(users, {
    fields: [businesses.ownerId],
    references: [users.id],
  }),
  serviceRequests: many(serviceRequests),
}));

export const serviceRequests = pgTable("service_requests", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  location: text("location").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  preferredDate: text("preferred_date"),
  status: text("status").notNull().default("new"),
  timestamp: timestamp("timestamp").notNull(),
  businessId: integer("business_id").references(() => businesses.id).notNull(),
  seen: boolean("seen").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const serviceRequestRelations = relations(serviceRequests, ({ one }) => ({
  business: one(businesses, {
    fields: [serviceRequests.businessId],
    references: [businesses.id],
  }),
}));

// Notification system
export const notificationTypes = pgEnum("notification_type", ["service_request", "status_update", "admin_action"]);

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: notificationTypes("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  relatedId: text("related_id"), // Can be service request ID, business ID, etc.
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notificationRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// Schemas for validation and insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
});

export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const insertBusinessSchema = createInsertSchema(businesses).omit({
  id: true,
  registrationDate: true,
  expiryDate: true,
  createdAt: true,
  updatedAt: true,
});

export const insertServiceRequestSchema = createInsertSchema(serviceRequests).omit({
  id: true,
  timestamp: true,
  businessId: true,
  seen: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export type UpsertUser = typeof users.$inferInsert;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Business = typeof businesses.$inferSelect;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type InsertServiceRequest = z.infer<typeof insertServiceRequestSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
